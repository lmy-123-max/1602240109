package com.dental.clinic.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dental.clinic.entity.SysPermission;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysPermissionMapper extends BaseMapper<SysPermission> {
}
